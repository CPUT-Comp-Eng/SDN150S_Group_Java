import java.util.Scanner;

public class CurrencyConverter {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {

            System.out.println("--- Crypto Converter Menu ---");
            System.out.println("1. Bitcoin to Ethereum");
            System.out.println("2. Ethereum to Bitcoin");
            System.out.println("3. Bitcoin to Litecoin");
            System.out.println("4. Litecoin to Bitcoin");
            System.out.println("5. Ethereum to Litecoin");
            System.out.println("6. Litecoin to Ethereum");
            System.out.println("7. Bitcoin to XRP");
            System.out.println("8. XRP to Bitcoin");
            System.out.println("9. Ethereum to XRP");
            System.out.println("10. XRP to Ethereum");
            
            System.out.print("\nChoose a pair (1-10): ");
            int choice = scanner.nextInt();
            
            System.out.print("Enter amount: ");
            double amount = scanner.nextDouble();
            
            double convertedAmount = 0.0;
            String pairName = "";
            boolean validChoice = true;
            
            switch (choice) {
                case 1 -> {
                    convertedAmount = amount * 14.5;
                    pairName = "ETH";
                }
                case 2 -> {
                    convertedAmount = amount * 0.069;
                    pairName = "BTC";
                }
                case 3 -> {
                    convertedAmount = amount * 420.0;
                    pairName = "LTC";
                }
                case 4 -> {
                    convertedAmount = amount * 0.0024;
                    pairName = "BTC";
                }
                case 5 -> {
                    convertedAmount = amount * 29.0;
                    pairName = "LTC";
                }
                case 6 -> {
                    convertedAmount = amount * 0.034;
                    pairName = "ETH";
                }
                case 7 -> {
                    convertedAmount = amount * 100000.0;
                    pairName = "XRP";
                }
                case 8 -> {
                    convertedAmount = amount * 0.00001;
                    pairName = "BTC";
                }
                case 9 -> {
                    convertedAmount = amount * 7000.0;
                    pairName = "XRP";
                }
                case 10 -> {
                    convertedAmount = amount * 0.00014;
                    pairName = "ETH";
                }
                default -> {
                    System.out.println("Invalid choice selection.");
                    validChoice = false;
                }
            }
            
            if (validChoice) {
                System.out.println("Converted total: " + convertedAmount + " " + pairName);
            }
        }}}
